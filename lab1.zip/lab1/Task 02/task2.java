import java.util.Scanner;
public class task2{

public static void main(String args[]){
Scanner src=new Scanner(System.in);
System.out.println("\nThis is a long string that is the the "+
                   "concatenation of two shorter strings.");
System.out.println("The first computer was invented about " +55+ 
                   " years ago.");
System.out.println("8 plus 5 is " + 8+5);
System.out.println("8 plus 5 is " +(8+5));
System.out.println(8+5+" equals 8 plus 5.");


}
}