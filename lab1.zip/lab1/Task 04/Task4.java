//Lab 01 --->Task -4

import java.util.Scanner;
public class task4{
public static void main(String args[]){
Scanner src=new Scanner(System.in);
System.out.println((10+5)*(4-6)/4);

}
}