import java.util.Scanner;
public class task6{

public static void main(String args[]){
Scanner src=new Scanner(System.in);
System.out.print("Enter the Dollors: ");
double dollors= src.nextDouble();
System.out.println("Values in rupees: "+dollors*300);


}
}