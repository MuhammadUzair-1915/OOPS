import java.util.Scanner;
public class task8{
public static void main(String args[]){
Scanner src=new Scanner(System.in);
System.out.print("Enter miles: ");
int sp=src.nextInt();
System.out.println("The convrt value is: "+(sp*1.6));

}
}